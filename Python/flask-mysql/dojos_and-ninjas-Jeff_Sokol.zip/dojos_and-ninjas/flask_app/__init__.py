from flask import Flask
app = Flask(__name__)
app.secret_key = "There is no fear in this dojo"