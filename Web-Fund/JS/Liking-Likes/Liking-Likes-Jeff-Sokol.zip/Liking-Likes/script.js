var arr = [9,12,9]

function likeUp(num){
    var y = "#id" + num;
    document.querySelector(y).innerText++;
}